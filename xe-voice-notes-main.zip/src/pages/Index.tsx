import { useState, useEffect } from 'react';
import { Car, Fuel, Mic, Plus, TrendingUp, History, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import VoiceRecorder from '@/components/VoiceRecorder';
import TransactionList from '@/components/TransactionList';
import StatsCard from '@/components/StatsCard';
import AddTransactionModal from '@/components/AddTransactionModal';
import ReportsSection from '@/components/ReportsSection';
import UserModeSelector from '@/components/UserModeSelector';
import { UserProvider } from '@/contexts/UserContext';
import { GoogleLogin, googleLogout } from '@react-oauth/google';
import { jwtDecode } from "jwt-decode";
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface FuelTransaction {
  id: string;
  date: string;
  amount: number;
  pricePerLiter: number;
  totalCost: number;
  location?: string;
  notes?: string;
  kmReading?: number;
  lastKmReading?: number;
}

const Index = () => {
  const [transactions, setTransactions] = useState<FuelTransaction[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<FuelTransaction | null>(null);
  const [activeTab, setActiveTab] = useState('history');
  const [googleUser, setGoogleUser] = useState<any>(null);

  // Load transactions from localStorage
  useEffect(() => {
    const savedTransactions = localStorage.getItem('fuelTransactions');
    if (savedTransactions) {
      setTransactions(JSON.parse(savedTransactions));
    }
  }, []);

  // Save transactions to localStorage
  useEffect(() => {
    localStorage.setItem('fuelTransactions', JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (transaction: Omit<FuelTransaction, 'id'>) => {
    const newTransaction: FuelTransaction = {
      ...transaction,
      id: Date.now().toString(),
    };
    setTransactions([newTransaction, ...transactions]);
  };

  const updateTransaction = (id: string, transaction: Omit<FuelTransaction, 'id'>) => {
    setTransactions(transactions.map(t => 
      t.id === id ? { ...transaction, id } : t
    ));
  };

  const deleteTransaction = (id: string) => {
    setTransactions(transactions.filter(t => t.id !== id));
  };

  const handleEditTransaction = (transaction: FuelTransaction) => {
    setEditingTransaction(transaction);
    setIsModalOpen(true);
  };

  const handleDuplicateTransaction = (transaction: FuelTransaction) => {
    const duplicatedTransaction = {
      ...transaction,
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0], // Set to today's date
    };
    setTransactions([duplicatedTransaction, ...transactions]);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTransaction(null);
  };

  const handleGoogleLoginSuccess = (credentialResponse: any) => {
    if (credentialResponse.credential) {
      const decoded: any = jwtDecode(credentialResponse.credential);
      setGoogleUser(decoded);
      // TODO: Lưu token để đồng bộ Google Drive
    }
  };

  const handleGoogleLogout = () => {
    googleLogout();
    setGoogleUser(null);
  };

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(transactions);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Transactions");
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/octet-stream' });
    saveAs(data, 'fuel-transactions.xlsx');
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text('Danh sách giao dịch đổ xăng', 14, 16);
    autoTable(doc, {
      startY: 24,
      head: [[
        'Ngày', 'Số lít', 'Giá/Lít', 'Tổng tiền', 'Địa điểm', 'Ghi chú', 'KM', 'KM trước'
      ]],
      body: transactions.map(t => [
        t.date,
        t.amount,
        t.pricePerLiter,
        t.totalCost,
        t.location || '',
        t.notes || '',
        t.kmReading || '',
        t.lastKmReading || ''
      ]),
    });
    doc.save('fuel-transactions.pdf');
  };

  // Thêm hàm xử lý nhập khẩu Excel
  const importFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = evt.target?.result;
      if (!data) return;
      const workbook = XLSX.read(data, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const json: any[] = XLSX.utils.sheet_to_json(sheet);

      // Chuyển đổi dữ liệu từ file Excel sang FuelTransaction
      //date	amount	pricePerLiter	totalCost	location	notes	kmReading	lastKmReading
      const imported: FuelTransaction[] = json.map((row, idx) => ({
        id: Date.now().toString() + idx, // tạo id duy nhất
        date: row['date'] || '',
        amount: Number(row['amount']) || 0,
        pricePerLiter: Number(row['pricePerLiter']) || 0,
        totalCost: Number(row['totalCost']) || 0,
        location: row['location'] || '',
        notes: row['notes'] || '',
        kmReading: row['kmReading'] ? Number(row['kmReading']) : 0,
        lastKmReading: row['lastKmReading'] ? Number(row['lastKmReading']) : 0,
      }));

      setTransactions(prev => [...imported, ...prev]);
      e.target.value = ''; // reset input để có thể import lại cùng file nếu muốn
    };
    reader.readAsBinaryString(file);
  };

  // Calculate total cost
  const totalCost = transactions.reduce((sum, t) => sum + t.totalCost, 0);
  // Calculate total liters
  const totalLiters = transactions.reduce((sum, t) => sum + t.amount, 0);
  // Calculate average price
  const averagePrice = totalLiters > 0 ? totalCost / totalLiters : 0;
  
  // Calculate average KM
  const transactionsWithKm = transactions.filter(t => t.kmReading && t.lastKmReading);
  const totalKmDriven = transactionsWithKm.reduce((sum, t) => 
    sum + (t.kmReading! - t.lastKmReading!), 0
  );
  const averageKmPerTransaction = transactionsWithKm.length > 0 ? 
    totalKmDriven / transactionsWithKm.length : 0;

  return (
    <UserProvider>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-orange-500 rounded-full">
                <Car className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-orange-600 bg-clip-text text-transparent">
                Fuel Tracker
              </h1>
            </div>
            <p className="text-muted-foreground text-lg">
              Ghi chép chi phí nhiên liệu bằng giọng nói
            </p>

            {/* Google Login Section */}
            <div className="flex justify-end mb-2">
              {googleUser ? (
                <div className="flex items-center gap-2">
                  <img src={googleUser.picture} alt="avatar" className="w-8 h-8 rounded-full" />
                  <span>{googleUser.name}</span>
                  <Button variant="outline" size="sm" onClick={handleGoogleLogout}>
                    Đăng xuất
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    Xuất Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    Xuất PDF
                  </Button>
                </div>
              ) : (
                <GoogleLogin
                  onSuccess={handleGoogleLoginSuccess}
                  onError={() => alert('Đăng nhập Google thất bại')}
                  useOneTap
                />
              )}
            </div>
          </div>

          {/* User Mode Selector */}
          <UserModeSelector />

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <StatsCard
              title="Tổng chi phí"
              value={`${totalCost.toLocaleString('vi-VN')} ₫`}
              icon={<TrendingUp className="w-5 h-5" />}
              gradient="from-green-500 to-emerald-500"
            />
            <StatsCard
              title="Tổng lít xăng"
              value={`${totalLiters.toFixed(1)} L`}
              icon={<Fuel className="w-5 h-5" />}
              gradient="from-blue-500 to-cyan-500"
            />
            <StatsCard
              title="Giá trung bình"
              value={`${averagePrice.toLocaleString('vi-VN')} ₫/L`}
              icon={<Car className="w-5 h-5" />}
              gradient="from-orange-500 to-red-500"
            />
            <StatsCard
              title="TB KM/lần"
              value={`${averageKmPerTransaction.toFixed(0)} km`}
              icon={<TrendingUp className="w-5 h-5" />}
              gradient="from-purple-500 to-pink-500"
            />
          </div>

          {/* Voice Recorder and Add Button */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8 justify-center">
            <VoiceRecorder 
              onTransactionParsed={addTransaction}
              isListening={isListening}
              setIsListening={setIsListening}
            />
            <Button 
              onClick={() => setIsModalOpen(true)}
              className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600 text-white px-6 py-3 text-lg"
              size="lg"
            >
              <Plus className="w-5 h-5 mr-2" />
              Thêm giao dịch
            </Button>
            <Button variant="outline" size="sm" onClick={exportToExcel}>
              Xuất Excel
            </Button>
            <Button variant="outline" size="sm" onClick={exportToPDF}>
              Xuất PDF
            </Button>
            <label>
              <input
                type="file"
                accept=".xlsx, .xls"
                onChange={importFromExcel}
                style={{ display: 'none' }}
              />
              <Button variant="outline" size="sm" asChild>
                <span>Nhập Excel</span>
              </Button>
            </label>
          </div>

          {/* Main Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="history" className="flex items-center gap-2">
                <History className="w-4 h-4" />
                Lịch sử đổ xăng
              </TabsTrigger>
              <TabsTrigger value="reports" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Báo cáo thống kê
              </TabsTrigger>
            </TabsList>

            <TabsContent value="history">
              <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Fuel className="w-5 h-5 text-orange-500" />
                    Lịch sử đổ xăng
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <TransactionList 
                    transactions={transactions}
                    onDelete={deleteTransaction}
                    onEdit={handleEditTransaction}
                    onDuplicate={handleDuplicateTransaction}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reports">
              <ReportsSection transactions={transactions} />
            </TabsContent>
          </Tabs>

          <AddTransactionModal
            isOpen={isModalOpen}
            onClose={handleCloseModal}
            onAdd={addTransaction}
            onUpdate={updateTransaction}
            editingTransaction={editingTransaction}
          />
        </div>
      </div>
    </UserProvider>
  );
};

export default Index;
