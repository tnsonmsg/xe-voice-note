
import { User, UserCheck, Cloud, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUser } from '@/contexts/UserContext';
import { useToast } from '@/hooks/use-toast';

const UserModeSelector = () => {
  const { isGuest, setIsGuest, syncToGoogleDrive, isSyncing, lastSyncTime } = useUser();
  const { toast } = useToast();

  const handleModeChange = (guest: boolean) => {
    setIsGuest(guest);
    toast({
      title: guest ? "Chế độ khách" : "Chế độ đăng ký",
      description: guest ? "Dữ liệu chỉ lưu trên thiết bị" : "Dữ liệu sẽ được đồng bộ lên Google Drive",
    });
  };

  const handleSync = async () => {
    await syncToGoogleDrive();
    toast({
      title: "Đồng bộ thành công",
      description: "Dữ liệu đã được sao lưu lên Google Drive",
    });
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="w-5 h-5" />
          Chế độ sử dụng
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex gap-2">
            <Button
              variant={isGuest ? "default" : "outline"}
              onClick={() => handleModeChange(true)}
              className="flex items-center gap-2"
            >
              <User className="w-4 h-4" />
              Khách
            </Button>
            <Button
              variant={!isGuest ? "default" : "outline"}
              onClick={() => handleModeChange(false)}
              className="flex items-center gap-2"
            >
              <UserCheck className="w-4 h-4" />
              Đăng ký
            </Button>
          </div>
          
          {!isGuest && (
            <div className="flex items-center gap-2">
              <Button
                onClick={handleSync}
                disabled={isSyncing}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                {isSyncing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Cloud className="w-4 h-4" />
                )}
                Đồng bộ
              </Button>
              {lastSyncTime && (
                <span className="text-sm text-muted-foreground">
                  Lần cuối: {lastSyncTime}
                </span>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default UserModeSelector;
