
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { FuelTransaction } from '@/pages/Index';

interface UserContextType {
  isGuest: boolean;
  setIsGuest: (guest: boolean) => void;
  syncToGoogleDrive: () => Promise<void>;
  isSyncing: boolean;
  lastSyncTime: string | null;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within UserProvider');
  }
  return context;
};

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider = ({ children }: UserProviderProps) => {
  const [isGuest, setIsGuest] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);

  // Load user mode from localStorage
  useEffect(() => {
    const savedMode = localStorage.getItem('userMode');
    if (savedMode === 'registered') {
      setIsGuest(false);
    }
  }, []);

  // Save user mode to localStorage
  useEffect(() => {
    localStorage.setItem('userMode', isGuest ? 'guest' : 'registered');
  }, [isGuest]);

  const syncToGoogleDrive = async () => {
    if (isGuest) return;
    
    setIsSyncing(true);
    try {
      // Simulate Google Drive sync
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const transactions = localStorage.getItem('fuelTransactions');
      if (transactions) {
        // In a real implementation, this would sync to Google Drive
        console.log('Syncing to Google Drive:', JSON.parse(transactions));
        setLastSyncTime(new Date().toLocaleString('vi-VN'));
      }
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const value: UserContextType = {
    isGuest,
    setIsGuest,
    syncToGoogleDrive,
    isSyncing,
    lastSyncTime,
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};
