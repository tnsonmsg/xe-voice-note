import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { GoogleOAuthProvider } from '@react-oauth/google';

createRoot(document.getElementById("root")!).render(
  <GoogleOAuthProvider clientId="43625205231-kif8c02lr32f9ipnomcg51sf9nu58amg.apps.googleusercontent.coms">
    <App />
  </GoogleOAuthProvider>
);
